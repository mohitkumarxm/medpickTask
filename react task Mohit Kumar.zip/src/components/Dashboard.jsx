import React from "react";
import ChartCard from "./ChartCard";
import HospitalCard from "./HospitalCard";
import Layout from "./Layout";

const Dashboard = () => {
  return (
    <div className>
      <Layout />
      {/* <HospitalCard />
      <ChartCard /> */}
    </div>
  );
};

export default Dashboard;
